
export const LeaderBoard = ({leaderboard}: {leaderboard: any}) => {
    return <div>
        Leaderboard 
        {JSON.stringify(leaderboard)}
    </div>
}