
export const CurrentQuestion = ({question}: {question: any}) => {
    return <div>
        {JSON.stringify(question)}
    </div>
}